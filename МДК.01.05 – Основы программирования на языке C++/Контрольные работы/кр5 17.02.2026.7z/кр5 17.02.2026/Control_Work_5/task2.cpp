#include <vector>
#include <numeric>
#include <algorithm>
#include <iostream>

int main() {
    std::vector<int> v(10);
    std::iota(v.begin(), v.end(), 1); // заполняем 1-10

    int sum = std::accumulate(v.begin(), v.end(), 0);
    long long prod = std::accumulate(v.begin(), v.end(), 1LL, std::multiplies<int>());
    auto [min, max] = std::minmax_element(v.begin(), v.end());

    std::cout << "Sum: " << sum << "\nProd: " << prod << "\nDiff: " << (*max - *min) << std::endl;
    return 0;
}