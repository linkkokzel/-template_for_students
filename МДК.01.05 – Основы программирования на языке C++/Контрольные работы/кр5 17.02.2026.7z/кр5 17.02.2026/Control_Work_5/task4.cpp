#include <chrono>
#include <iostream>

void bench() {
    auto s = std::chrono::steady_clock::now();
    for(int i=0; i<10000000; ++i); // пустой цикл
    auto e = std::chrono::steady_clock::now();
    std::cout << "Time: " << std::chrono::duration_cast<std::chrono::milliseconds>(e-s).count() << "ms\n";
}

int main() {
    bench(); // замер 1
    // Повтори аналогично для цикла с квадратами чисел
    return 0;
}