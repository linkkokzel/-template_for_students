#include <string>
#include <vector>
#include <sstream>
#include <set>
#include <iostream>

int main() {
    std::string s = "apple, banana, orange, apple, kiwi";
    std::stringstream ss(s);
    std::string word;
    std::set<std::string> words; // set сам удаляет повторы и сортирует

    while (std::getline(ss, word, ',')) {
        word.erase(0, word.find_first_not_of(" ")); // убираем пробелы
        words.insert(word);
    }

    for (const auto& w : words) 
        {
            std::cout << w << " ";
        }
           return 0;
}