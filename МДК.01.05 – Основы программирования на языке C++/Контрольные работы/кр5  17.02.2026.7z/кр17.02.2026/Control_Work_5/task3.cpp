#include <fstream>
#include <vector>
#include <numeric>
#include <iostream>

int main() {
    std::ofstream out("numbers.txt");
    for(int i : {1, 2, 3, 4, 5}) out << i << " ";
    out.close();

    std::ifstream in("numbers.txt");
    std::vector<int> v;
    int n;
    while (in >> n) v.push_back(n);

    double avg = std::accumulate(v.begin(), v.end(), 0.0) / v.size();
    std::cout << "Average: " << avg << std::endl;
    return 0;
}