#include <string>
#include <stdexcept>
#include <iostream>

int main() {
    std::string input;
    std::cout << "Enter number: ";
    std::cin >> input;

    try {
        int num = std::stoi(input);
        if (num < 0) throw std::runtime_error("Negative!");
        std::cout << "Number: " << num;
    } catch (const std::exception& e) {
        std::cout << "Error: " << e.what() << std::endl;
    }
    return 0;
}