#include <iostream>
#include <vector>
#include <string>
using namespace std;

// Задание 1
struct Engine {
    string model;
    int power;
};

struct Car {
    string brand;
    int year;
    Engine engine;
};

void printCarInfo(const Car& car) {
    cout << "Марка: " << car.brand << endl;
    cout << "Год выпуска: " << car.year << endl;
    cout << "Двигатель: " << car.engine.model 
         << " (" << car.engine.power << " л.с.)" << endl;
}

// Задание 2
struct Author {
    string name;
    string country;
};

struct Book {
    string title;
    int year;
    Author author;
};

void printBooks(const vector<Book>& books) {
    cout << "\nСписок книг:" << endl;
    for (const auto& book : books) {
        cout << "\"" << book.title << "\" (" << book.year << "), "
             << "Автор: " << book.author.name 
             << " (" << book.author.country << ")" << endl;
    }
}

// Задание 3
struct Student {
    string name;
    string city;
};

void findStudentsByCity(const vector<Student>& students, const string& city) {
    cout << "\nСтуденты из города " << city << ":" << endl;
    bool found = false;
    for (const auto& student : students) {
        if (student.city == city) {
            cout << "- " << student.name << endl;
            found = true;
        }
    }
    if (!found) {
        cout << "Не найдено" << endl;
    }
}

// Задание 4 (комментарий в коде)
/*
Почему композиция безопаснее наследования на ранних этапах разработки?

1. Меньшая связанность: композиция создает менее жесткие связи между объектами
2. Гибкость: легче менять поведение, заменяя компоненты
3. Избегание проблем иерархии: нет риска неправильного проектирования наследования
4. Тестируемость: компоненты можно тестировать изолированно
5. Принцип единственной ответственности: каждый класс отвечает за конкретную задачу
6. Избегание хрупкого базового класса: изменения в родительском классе не ломают дочерние
*/

int main() {
    // Задание 1
    
    Car myCar = {"Toyota", 2022, {"2JZ-GTE", 320}};
    printCarInfo(myCar);

    // Задание 2
    
    vector<Book> library = {
        {"Преступление и наказание", 1866, {"Федор Достоевский", "Россия"}},
        {"1984", 1949, {"Джордж Оруэлл", "Великобритания"}},
        {"Мастер и Маргарита", 1967, {"Михаил Булгаков", "Россия"}}
    };
    printBooks(library);

    // Задание 3
    
    vector<Student> students = {
        {"Иван Иванов", "Москва"},
        {"Петр Петров", "Санкт-Петербург"},
        {"Анна Сидорова", "Москва"},
        {"Мария Кузнецова", "Казань"}
    };
    
    findStudentsByCity(students, "Москва");
    findStudentsByCity(students, "Воронеж");

    return 0;
}