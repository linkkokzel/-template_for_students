//задание 1

#include <iostream>
#include <string>
using namespace std;

struct Student {
    string name;
    int age;
    double grade;
};

int main() {
    Student group[4] = {
        {"Анна", 20, 4.8},
        {"Борис", 21, 3.9},
        {"Виктор", 19, 5.0},
        {"Глеб", 22, 4.3}
    };

    cout << "Студенты с баллом выше 4.5:\n";
    for (const auto& student : group) {
        if (student.grade > 4.5) {
            cout << student.name << " (" << student.grade << ")\n";
        }
    }
    return 0;
}

// задание 2 

#include <iostream>
#include <vector>
#include <string>
using namespace std;

struct Student {
    string name;
    int age;
    string subject; // Предмет
    double grade;
};

int main() {
    vector<Student> students = {
        {"Анна", 20, "Биология", 4.8},
        {"Борис", 21, "Химия", 4.2},
        {"Виктор", 19, "Биология", 5.0},
        {"Глеб", 22, "Физика", 4.5},
        {"Дарья", 20, "Биология", 4.9}
    };

    double maxBioGrade = -1.0;
    string bestBioStudent;

    for (const auto& s : students) {
        if (s.subject == "Биология" && s.grade > maxBioGrade) {
            maxBioGrade = s.grade;
            bestBioStudent = s.name;
        }
    }

    if (!bestBioStudent.empty()) {
        cout << "Лучший студент по Биологии: " << bestBioStudent 
             << " (балл: " << maxBioGrade << ")\n";
    } else {
        cout << "Студентов по Биологии не найдено.\n";
    }
    return 0;
}

//задание 3

#include <iostream>
#include <vector>
#include <string>
#include <algorithm> // для find_if
using namespace std;

struct Student {
    int id; // Уникальный номер
    string name;
    double grade;
};

// Прототипы функций
void addStudent(vector<Student>& v);
void editStudent(vector<Student>& v);
void deleteStudent(vector<Student>& v);
void searchStudent(const vector<Student>& v);
void showAll(const vector<Student>& v);

int main() {
    vector<Student> students;
    int choice;

    do {
        cout << "\n--- Система управления студентами ---\n";
        cout << "1. Добавить студента\n";
        cout << "2. Редактировать студента\n";
        cout << "3. Удалить студента\n";
        cout << "4. Найти студента по имени\n";
        cout << "5. Показать всех\n";
        cout << "0. Выход\n";
        cout << "Выбор: ";
        cin >> choice;

        switch (choice) {
            case 1: addStudent(students); break;
            case 2: editStudent(students); break;
            case 3: deleteStudent(students); break;
            case 4: searchStudent(students); break;
            case 5: showAll(students); break;
        }
    } while (choice != 0);

    return 0;
}

void addStudent(vector<Student>& v) {
    Student s;
    static int nextId = 1; // Генератор ID
    s.id = nextId++;
    cout << "Введите имя: ";
    cin >> s.name;
    cout << "Введите балл: ";
    cin >> s.grade;
    v.push_back(s);
    cout << "Студент добавлен с ID: " << s.id << endl;
}

void editStudent(vector<Student>& v) {
    int id;
    cout << "Введите ID студента для редактирования: ";
    cin >> id;

    for (auto& s : v) {
        if (s.id == id) {
            cout << "Новое имя (текущее: " << s.name << "): ";
            cin >> s.name;
            cout << "Новый балл (текущий: " << s.grade << "): ";
            cin >> s.grade;
            cout << "Данные обновлены.\n";
            return;
        }
    }
    cout << "Студент с ID " << id << " не найден.\n";
}

void deleteStudent(vector<Student>& v) {
    int id;
    cout << "Введите ID студента для удаления: ";
    cin >> id;

    for (auto it = v.begin(); it != v.end(); ++it) {
        if (it->id == id) {
            v.erase(it);
            cout << "Студент удален.\n";
            return;
        }
    }
    cout << "Студент не найден.\n";
}

void searchStudent(const vector<Student>& v) {
    string name;
    cout << "Введите имя для поиска: ";
    cin >> name;

    bool found = false;
    for (const auto& s : v) {
        if (s.name == name) {
            cout << "Найден: ID " << s.id << ", Имя: " << s.name << ", Балл: " << s.grade << endl;
            found = true;
        }
    }
    if (!found) {
        cout << "Студент с именем " << name << " не найден.\n";
    }
}

void showAll(const vector<Student>& v) {
    if (v.empty()) {
        cout << "Список студентов пуст.\n";
        return;
    }
    cout << "--- Список студентов ---\n";
    for (const auto& s : v) {
        cout << "ID: " << s.id << ", Имя: " << s.name << ", Балл: " << s.grade << endl;
    }
}