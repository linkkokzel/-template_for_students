#include <iostream>
#include <windows.h>
#include <vector>
#include <iomanip>

enum class AnotherCategory {
    man, woman, boy, girl
};

enum class ProductCategory {
    // обувь, верхняя одежда, средняя одежда, нижняя одежда
    shoes, top_clothes, middle_clothes, down_clothes
};

struct Product{
    std::string name;
    ProductCategory category1;
    AnotherCategory category2;
    int size;
    std::string unit;  // единицы измерения (шт, пара, и т.д.)
    double price; 
    int count;
};

using Inventory = std::vector<Product>;
using Cart = std::vector<Product>;

std::string category1ToString (ProductCategory category) {
    switch (category) {
        case ProductCategory::shoes: return "обувь";
        case ProductCategory::top_clothes: return "верхняя одежда";
        case ProductCategory::middle_clothes: return "средняя одежда";
        case ProductCategory::down_clothes: return "нижняя одежда";
        default: return "";
    }
}

std::string category2ToString (AnotherCategory category2) {
    switch (category2) {
        case AnotherCategory::man: return "мужская";
        case AnotherCategory::woman: return "женская";
        case AnotherCategory::boy: return "детская для мальчиков";
        case AnotherCategory::girl: return "детская для девочек";
    }
}

void printProducts(const Inventory& inventory) {
    std::cout << std::fixed << std::setprecision(2);
    for (size_t i = 0; i < inventory.size(); ++i) {
        std::cout << i + 1 << ". " << inventory[i].name 
                  << " | Категория: " << category1ToString(inventory[i].category1)
                  << ", " << category2ToString(inventory[i].category2)
                  << " | Размер: " << inventory[i].size
                  << " | Ед. изм.: " << inventory[i].unit
                  << " | Цена: " << inventory[i].price << " руб." << std::endl;
    }
}

void addToCart(Cart& cart, const Inventory& inventory, int index, int quantity) {
    if (index < 0 || index >= static_cast<int>(inventory.size())) {
        std::cout << "Неверный номер товара!" << std::endl;
        return;
    }
    if (quantity <= 0) {
        std::cout << "Количество должно быть больше 0!" << std::endl;
        return;
    }
    
    Product productToAdd = inventory[index];
    productToAdd.count = quantity;
    
    // Проверяем, есть ли уже такой товар в корзине
    bool found = false;
    for (auto& item : cart) {
        if (item.name == productToAdd.name && item.size == productToAdd.size) {
            item.count += quantity;
            found = true;
            std::cout << "Товар добавлен в корзину! (Всего: " << item.count << " " << item.unit << ")" << std::endl;
            break;
        }
    }
    
    if (!found) {
        cart.push_back(productToAdd);
        std::cout << "Товар добавлен в корзину!" << std::endl;
    }
}

void printCart(const Cart& cart) {
    double total = 0.0;
    std::cout << "\n---Ваша корзина---" << std::endl;
    if (cart.empty()) {
        std::cout << "Ваша корзина пустая" << std::endl;
        return;
    }
    std::cout << std::fixed << std::setprecision(2);
    for (const auto& product : cart) {
        double itemTotal = product.price * product.count;
        std::cout << "- " << product.name 
                  << " | " << category1ToString(product.category1) 
                  << ", " << category2ToString(product.category2)
                  << " | Размер: " << product.size
                  << " | " << product.count << " " << product.unit
                  << " x " << product.price << " руб. = "
                  << itemTotal << " руб." << std::endl;
        total += itemTotal;
    }

    std::cout << "------------------------------" << std::endl;
    std::cout << "Итого: " << total << " руб." << std::endl;
}

int main() {
    SetConsoleOutputCP(CP_UTF8);
    std::cout << "Добро пожаловать в магазин одежды!" << std::endl;
    
    Inventory storeInventory = {
        {"Кроссовки Abibas", ProductCategory::shoes, 
        AnotherCategory::man, 43, "пара", 5000.0, 0},
        {"Кроссовки Nike", ProductCategory::shoes,
        AnotherCategory::woman, 39, "пара", 6000.0, 0},
        {"Куртка Adidas", ProductCategory::top_clothes,
        AnotherCategory::man, 50, "шт", 9000.0, 0},
        {"Джинсы", ProductCategory::down_clothes,
        AnotherCategory::woman, 46, "шт", 3000.0, 0},
        {"Футболка", ProductCategory::middle_clothes,
        AnotherCategory::man, 52, "шт", 2000.0, 0},
        {"Платье", ProductCategory::middle_clothes,
        AnotherCategory::woman, 44, "шт", 4500.0, 0}
    };

    Cart userCart;
    bool isShopping = true;
    
    while (isShopping) {
        std::cout << "\n=== МЕНЮ ===" << std::endl;
        std::cout << "1. Просмотреть товары" << std::endl;
        std::cout << "2. Добавить товар в корзину" << std::endl;
        std::cout << "3. Просмотреть корзину" << std::endl;
        std::cout << "4. Выход" << std::endl;
        std::cout << "Выберите действие: ";
        
        int choice;
        std::cin >> choice;
        
        switch (choice) {
            case 1: {
                std::cout << "\n---Ассортимент магазина---" << std::endl;
                printProducts(storeInventory);
                break;
            }
            case 2: {
                std::cout << "\n---Ассортимент магазина---" << std::endl;
                printProducts(storeInventory);
                std::cout << "\nВведите номер товара: ";
                int productIndex;
                std::cin >> productIndex;
                std::cout << "Введите количество: ";
                int quantity;
                std::cin >> quantity;
                addToCart(userCart, storeInventory, productIndex - 1, quantity);
                break;
            }
            case 3: {
                printCart(userCart);
                break;
            }
            case 4: {
                isShopping = false;
                std::cout << "\nСпасибо за покупки! До свидания!" << std::endl;
                break;
            }
            default: {
                std::cout << "Неверный выбор! Попробуйте снова." << std::endl;
                break;
            }
        }
    }
    
    return 0;
}